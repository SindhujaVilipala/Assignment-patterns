package question4;

public class staticndprivate1 extends staticndprivate {
	

		private static void display() {

		System.out.println("static");

		}

		public void print() {

		System.out.println("not a static");

		}
}
