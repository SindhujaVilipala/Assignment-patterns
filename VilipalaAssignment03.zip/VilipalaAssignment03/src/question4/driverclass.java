package question4;

public class driverclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		staticndprivate obj= new staticndprivate1();
		obj.display();
		obj.print();

	}

}
