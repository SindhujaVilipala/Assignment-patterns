package question4;

public class staticndprivate {

		private static void display() {

		System.out.println("Static");

		}

		public void print() {

		System.out.println("not a static");

		}

	}


