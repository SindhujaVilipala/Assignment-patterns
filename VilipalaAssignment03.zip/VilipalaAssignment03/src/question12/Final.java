package question12;

public class Final {
	 final int age = 18;  
	    void display() {  
	    age = 55;  
	    }  
public static void main(String[] args) {  
		      
		    Final f = new Final();  
		   
		    f.display();  
		    }  
 
	}

