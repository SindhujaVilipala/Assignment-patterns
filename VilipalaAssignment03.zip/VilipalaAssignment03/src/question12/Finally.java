package question12;

public class Finally {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		      try {    
		        System.out.println("try block");  
		     
		       int data=25/0;    
		       System.out.println(data);    
		      }   
		    
		      finally {  
		        System.out.println("finally block");  
		      }    
		         
		      }    
	}


