package question5;

public class stringBufferndBuilde {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 StringBuffer buffer=new StringBuffer("hello"); 
		 StringBuilder builder=new StringBuilder("hello"); 
		 buffer.append("java");  
	     builder.append("java"); 
	     System.out.println(buffer); 
	     System.out.println(builder);  
	      
	}

}
