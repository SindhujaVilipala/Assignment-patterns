package question6;

public class DriverClass extends StringndBuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 long startTime = System.currentTimeMillis();  
	        concatWithString();  
	        System.out.println((System.currentTimeMillis()-startTime)+"ms");  
	        startTime = System.currentTimeMillis();  
	        concatWithStringBuffer();  
	        System.out.println((System.currentTimeMillis()-startTime)+"ms");  
	    }  
	}


