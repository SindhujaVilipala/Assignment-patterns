package question13;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class VectorClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<String> names=new Vector<String>();
	    names.add("Sindhu");
	    names.add("Sri");
	    names.add("Vidya");
	    names.add("Anitha");
	    //Iterating the array list using iterator
	    System.out.println("VectorClass elements: ");
	    Iterator itr=names.iterator();
	    while(itr.hasNext()){
	      System.out.println(itr.next());
	    }
	  }
	

}
