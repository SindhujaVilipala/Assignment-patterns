package question13;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListClass {
	public static void main(String args[]){

	    List<String> names=new ArrayList<String>();
	    names.add("Sindhu");
	    names.add("Sri");
	    names.add("Vidya");
	    names.add("Anitha");
	    //Iterating the array list using iterator
	    System.out.println("ArrayListClass elements: ");
	    Iterator itr=names.iterator();
	    while(itr.hasNext()){
	      System.out.println(itr.next());
	    }
	  }
}
