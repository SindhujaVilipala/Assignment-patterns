package generics;

public class generic {

}
