package question3;

public class CovariantQuestion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Covariant1 a1 = new Covariant1();  
	       a1.foo().print();    
	       Covariant2 a2 = new Covariant2();  
	       ((Covariant2)a2.foo()).print();  
	}

}
