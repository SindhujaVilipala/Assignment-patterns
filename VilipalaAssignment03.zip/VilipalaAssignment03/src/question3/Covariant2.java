package question3;

public class Covariant2 extends Covariant1{
    @Override  
    Covariant2 foo()  
    {  
        return this;  
    }  
      
    void print()  
    {  
        System.out.println("WithIN the covariant2 class");  
    }  

}
