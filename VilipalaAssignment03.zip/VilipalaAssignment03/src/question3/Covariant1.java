package question3;

public class Covariant1 {
	 Covariant1 foo()  
	    {  
	        return this;  
	    }  
	      
	    void print()  
	    {  
	        System.out.println("WithIn the covarient class");  
	    }  
}
