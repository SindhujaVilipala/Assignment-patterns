package question10;

public class superClass {
	void methodOfSuperClass()
    {
        System.out.println("This class will not throwing any exception");
    }
}
