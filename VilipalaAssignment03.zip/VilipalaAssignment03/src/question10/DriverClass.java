package question10;

public class DriverClass extends superClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    superClass p = new subClass();
    p.methodOfSuperClass();
	}

}
