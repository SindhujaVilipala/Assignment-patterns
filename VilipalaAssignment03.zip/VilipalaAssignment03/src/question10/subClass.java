package question10;

public class subClass extends superClass{

	
	    void methodOfSuperClass() throws NullPointerException
	    {
	        System.out.println("can be overrided");
	    }
	}


