package question17;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class FailIfast {
	   

        public static void main(String[] args)   
        {   
            Map<String, String> em = new HashMap<String, String>();   
            em.put("a", "A");   
            em.put("b", "B");   
            em.put("c", "C");   
            Iterator iterator = em.keySet().iterator();   
            while (iterator.hasNext()) {   
                System.out.println(em.get(iterator.next()));    
                em.put("d", "D");   
            }   
        }   
      
}
