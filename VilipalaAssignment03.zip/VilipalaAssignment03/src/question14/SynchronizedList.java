package question14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class SynchronizedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 List<String> li = new ArrayList<String>();
	      li.add("sindhu");
	      li.add("sri");
	      li.add("vidya");
	      li.add("Anitha");
	      List<String> synlist = Collections.synchronizedList(li);
	      synchronized(synlist) {
	         Iterator<String> itr = synlist.iterator();
	         while(itr.hasNext()) {
	            String str = itr.next();
	            System.out.println(str);
	         }
	      }
	   }
}
