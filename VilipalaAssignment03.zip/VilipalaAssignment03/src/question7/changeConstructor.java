package question7;

public class changeConstructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	      String Str;
	      final public changeConstructor(){
	         Str = "Hi";
	}
}
