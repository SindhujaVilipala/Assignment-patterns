package question21;

public class serialization {

}
