package question18;

public class Twicethread {

}
